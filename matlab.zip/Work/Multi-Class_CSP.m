%% Multi-class CSP based on : https://doi.org/10.1109/IEMBS.2005.1616947 ...
% by Wu, Gao and Gao, EMBC (2005)

m = 2;

for i = 1:size(train,2) % Compute all of the covariance matrices separetly 

    class1 = train(i).L'; % (NxT) 
    class2 = train(i).R';
    class3 = train(i).Re';
    
    R1(:,:,i) = covar(class1); % Equation (1) : Class Covariance Matrix
    R2(:,:,i) = covar(class2);
    R3(:,:,i) = covar(class3);  
end
R1 = mean(R1,3);
R2 = mean(R2,3);
R3 = mean(R3,3);
R = R1 + R2 + R3; % Equation (2): Composite Covariance Matrix

[V,D] = eig(R); % V = U and D = Lamba as denoted in (3) : U is the NxN unitary matrix of PC ... 
% Lambda is the NxN Diagonal matrix of eigenvalues

W = sqrtm(inv(D)) * V'; % Whitening Matrix: W = inverse square root(D) * U' (4)

%% Left 
% To take the CSP of a specific task (e.g. Class 1). Let Ra' = Rb + Rc then
% Ra and Ra' are Sa = W Ra W'

Ra = R1; % Class 1

Rbc = R2 + R3; % Class 2 and 3 (Equation Ra' = Rb + Rc);

Sa = W  * Ra * W'; 
Sbc = W * Rbc * W';

[SaV, SaD] = decompose_S(Sa, 'descending');
[SbcVt, SbcDt] = decompose_S(Sbc, 'ascending');


check = SaD + SbcDt; 
check = mean(check);

SaV(:,[m+1:end]) = [];

SFa = SaV' * W; % Equation (12) : Spatial Filter for Class A

for i = 1:size(train,2)
    Za = SFa * train(i).L'; % Resulting matrix size will be 2xT

    var1 = var(Za, 1, 2);
    varsum = sum(var1);
    featL(i,:) = log10(var1/varsum);
    clear var1 varsum
end


%clear Ra Rbc Sa Sbc SaV SaD SbcVt SbcDt check 
%% Right 
% To take the CSP of a specific task (e.g. Class 1). Let Ra' = Rb + Rc then
% Ra and Ra' are Sa = W Ra W'

Ra = R2; % Class 2

Rbc = R1 + R3; % Class 1 and 3 (Equation Ra' = Rb + Rc);

Sa = W  * Ra * W'; 
Sbc = W * Rbc * W';

[SaV, SaD] = decompose_S(Sa, 'descending');
[SbcVt, SbcDt] = decompose_S(Sbc, 'ascending');

check = SaD + SbcDt; 
check = mean(check);

SaV(:,[m+1:end]) = [];

SFb = SaV' * W; % Equation (12) : Spatial Filter for Class B

for i = 1:size(train,2)
    Zb = SFb * train(i).R'; % Resulting matrix size will be 2xT

    var1 = var(Zb, 1, 2);
    varsum = sum(var1);
    featR(i,:) = log10(var1/varsum);
    clear var1 varsum
end


clear Ra Rbc Sa Sbc SaV SaD SbcVt SbcDt check 
%% Rest
% To take the CSP of a specific task (e.g. Class 1). Let Ra' = Rb + Rc then
% Ra and Ra' are Sa = W Ra W'

Ra = R3; % Class 3

Rbc = R1 + R2; % Class 1 and 2 (Equation Ra' = Rb + Rc);

Sa = W  * Ra * W'; 
Sbc = W * Rbc * W';

[SaV, SaD] = decompose_S(Sa, 'descending');
[SbcVt, SbcDt] = decompose_S(Sbc, 'ascending');

check = SaD + SbcDt; 
check = mean(check);

SaV(:,[m+1:end]) = [];

SFc = SaV' * W; % Equation (12) : Spatial Filter for Class C

for i = 1:size(train,2)
    Zc = SFc * train(i).Re'; % Resulting matrix size will be 2xT

    var1 = var(Zc, 1, 2);
    varsum = sum(var1);
    featRe(i,:) = log10(var1/varsum);
    clear var1 varsum
end

clear Ra Rbc Sa Sbc SaV SaD SbcVt SbcDt check 

%%

feat = [featL;featR;featRe];
label = [ones(size(train,2),1); ones(size(train,2),1) .* 2; ones(size(train,2),1) .* 3];

% 1 = L, 2 = R, 3 = Re


% LambdaB  = diag(SFa * R2 * SFa');
% LambdaC = diag(SFa * R3 * SFa');


