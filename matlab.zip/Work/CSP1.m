%% This CSP computes covariance matrix of lEEG + reEEG based on my old way

% Average covariance of Left and Right
m = 2;
Cr = zeros(size(train(1,1).R,2),size(train(1,1).R,2));
Clre = zeros(size(train(1,1).LRE,2),size(train(1,1).LRE,2));
featR = zeros(size(train,2),m*2);
featLRE = zeros(size(train,2),m*2);

for i = 1:size(train,2)
    Cr = Cr + covar(train(i).R');
    Clre = Clre + covar(train(i).LRE');
end

Cr = Cr ./ size(train,2);
Clre = Clre ./ size(train,2);

% Found to average covariance matrices so far

R = Cr + Clre; % (2)
% Eigen decomp of R (2)
[V,D] = eig(R); % V = U and D = Sigma as denoted in (2)

% Whitening Matrix: P = inverse square root(D) * U' (3)
P = sqrtm(inv(D)) * V';
% Sl = P*Cl*P'  Sr = P*Cr*P' (4)
sR = P*Cr*P';
sLRE = P*Clre*P';

% If we eig decomp sL and sR, the sum of eigenvalues should be an
% identity matrix of NxN. (5)
[srV2,srD2] = decompose_S(sR,'ascending');
[slreV2,slreD2] = decompose_S(sLRE,'descending');

check = slreD2+srD2; % All are 1, which means I.D Matrix confirmed. (5)
% if check ~= 1
%     error('I.D Matrix not confirmed');
% end

% Projection Matrix: W = U'*P where U' is slV2 and P is whitening matrix (6)

W = srV2' * P; %(6)
% Computing Z: Z = WX (7)
%    W = W();
%    Z(:,:,i) =
%    Z = [];
%
%m = 2; % First two columns and last 2 columns, like PCA choose most variant columns
x = W;
x([m+1:end-m],:) = [];
W2 = x;
for j = 1:size(train,2)
    train(j).Zr = W2 * train(j).R';
    train(j).Zlre = W2 * train(j).LRE';
end

% Feature vector array. Trial X Bandwidth: 72 x 36 where 1:4 is 4-8Hz,
% 5-8 is 8-12Hz and so on.
for j = 1:size(train,2)
    var1 = var(train(j).Zr, 1, 2);
    varsum = sum(var1);
    featR(j,:) = log10(var1/varsum);
    clear var1 varsum
    
    var1 = var(train(j).Zlre, 1, 2);
    varsum = sum(var1);
    featLRE(j,:) = log10(var1/varsum);
    clear var1 varsum
end


% Adding True label and mergin feature vector
% TRUE LABEL
true_right = ones(size(featR, 1), 1);
true_rre = zeros(size(featLRE, 1), 1);

% FEATURE + TRUE LABEL
right = [featR, true_right];
rre = [featLRE, true_rre];

% MERGE LEFT AND RIGHT
train_feat = [right; rre];

% SHUFFLE TRAINING DATA
train_feat = train_feat(randperm(size(train_feat, 1)), :);

clearvars -except W2 train_feat train bp

% Mutual Information based selection of Bands
x_train = train_feat(:,[1:end-1]);
y_train = train_feat(:,end);

uniqueLabels = unique(y_train);

% Define colors for each class
colors = lines(numel(uniqueLabels)); % Generate a colormap

hold on; % Hold on to plot each class separately

% Loop through each unique label and plot them separately
for i = 1:numel(uniqueLabels)
    classIdx = y_train == uniqueLabels(i);
    scatter(x_train(classIdx, 1), x_train(classIdx, end), 18, 'filled', 'MarkerFaceColor', colors(i,:));
end

% Customize the legend
legendEntries = arrayfun(@(x) ['Class ' num2str(x)], uniqueLabels, 'UniformOutput', false);
legend(legendEntries);

% Set the axis labels for clarity
xlabel('Feature 1');
ylabel('Feature 2');

% Add a title
title('Scatter Plot of Left Features with Class Labels');

hold off; % Release the hol