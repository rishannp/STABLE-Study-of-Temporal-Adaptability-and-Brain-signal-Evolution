% Define the folder names
folder1 = 'eegLS';
folder2 = 'eegGH';

% Get the list of files in each folder
filesInFolder1 = dir(fullfile(folder1, '*'));
filesInFolder2 = dir(fullfile(folder2, '*'));

% Filter out the directories (if any) from the file lists
filesInFolder1 = filesInFolder1(~[filesInFolder1.isdir]);
filesInFolder2 = filesInFolder2(~[filesInFolder2.isdir]);

% Extract the file names from the structures
LS = {filesInFolder1.name};
GH = {filesInFolder2.name};

clear filesInFolder1 filesInFolder2 folder1 folder2
%% states.PresentationPhase == The label for up down and resting 
% Variable loading, this is the inputs to the function for later
config.fs = 500; % Original Fs
config.resample1 = 1; % Resample Rate numerator
config.resample2 = 2; % Resample Rate denominator (1/2)
config.workingfs = config.fs * (config.resample1/config.resample2);
config.plen = 500; % Processing Data Length
config.class = 3; % Number of Classes
config.alias = 'LS'; % Patient alias (SELECTABLE INPUT FOR PATIENT DATA)
config.patient = LS; % Patient data (SELECTABLE INPUT FOR PATIENT DATA)
config.trainingduration = 2; %How many session's of data is used to train
config.channel = 'Parietal'; % Option of 10-10, 10-20 or Parietal
config.trainFiles = findSession(config); % Tracks the files used for Training

if config.alias == 'LS' % Automatically select appropriate BPF
    config.bpf = [55 85];
else config.alias = 'GH';
    config.bpf = [1 5];
end


%% Pseudo - Live Data streaming loop

for i = length(config.trainFiles):length(config.patient) % Loop to hold patient session data

    % Training loop
    if i == length(config.trainFiles) % When on the initial iteration of the loop, train
        [train,config] = trainPreProcess(config); % Preprocess and gather all the training data
        [mdl,accuracy, SF, W, feat, label] = training(train,5);
    else

        [signal,label] = testPreProcess(config,i); % Gather the testing data unseen by model

        for j = 1:config.plen:length(signal) % Loop to iterate through data in session 'live'

            workingdata = signal(j:(j+config.plen)-1,:); % Incoming EEG Data
            workinglabel = label(j:(j+config.plen)-1,:); % Label for incoming data
            

        end

    end
end


%%

