%% Create a function to take in raw data for training

tic % Start timer

% Goal Split -> Create Up/Down, Up/NC, Down/NC -> Then use the CSP function

% Define the folder names
folder1 = 'eegLS';
folder2 = 'eegGH';

% Get the list of files in each folder
filesInFolder1 = dir(fullfile(folder1, '*'));
filesInFolder2 = dir(fullfile(folder2, '*'));

% Filter out the directories (if any) from the file lists
filesInFolder1 = filesInFolder1(~[filesInFolder1.isdir]);
filesInFolder2 = filesInFolder2(~[filesInFolder2.isdir]);

% Extract the file names from the structures
LS = {filesInFolder1.name};
GH = {filesInFolder2.name};

clear filesInFolder1 filesInFolder2 folder1 folder2

config.fs = 1000; % Original Fs
config.resample1 = 1; % Resample Rate numerator
config.resample2 = 2; % Resample Rate denominator (1/2)
config.workingfs = config.fs * (config.resample1/config.resample2);
config.plen = 500; % Processing Data Length
config.class = 3; % Number of Classes
config.patient = LS; % Patient data
config.patient = delOdds(config);
config.bpf = [50 90];
config.trainingduration =  1; %How many session's of data is used to train
config.channel = 'Parietal'; % Option of 10-10, 10-20 or Parietal
config.trainFiles = findSession(config); % Tracks the files used for Training


[train,config] = trainPreProcess(config); % Preprocess and gather all the training data
plotEEGlocs(config); % Plot the electrode array



%%
[mdl,accuracy, SF, W, feat, label] = training(train,5); % train 
[testdata,groundtruth] = testPreProcess(config,size(config.trainFiles,2)+1); % Gather the testing data unseen by model



%%
predClass = zeros(1,[round(length(testdata)/config.plen)]);
x=1;
for i = 1:config.plen:length(testdata)-config.plen
    [currentfeat,currentlabel] = testfeatextract(W,SF,testdata([i:i+config.plen],:),groundtruth(i:i+config.plen));
    [prediction,scores] = mdl.predictFcn(currentfeat');
    % Find elements that are equal to 1 and set them to 0
    scores(scores == 1) = 0;
    [~,predClass(x)] = max(sum(scores));

    x=x+1;
end
predClass = repelem(predClass, config.plen);
predClass = predClass(1,[1:length(groundtruth)])';
res = (groundtruth == predClass);
acc = sum(res)/length(res)*100;


toc % Stop and readout timer

%% Function
