%% G-W Dataset

%% Load Folder/file names

% Define the folder names
folder1 = 'eegLS';
folder2 = 'eegGH';

% Get the list of files in each folder
filesInFolder1 = dir(fullfile(folder1, '*'));
filesInFolder2 = dir(fullfile(folder2, '*'));

% Filter out the directories (if any) from the file lists
filesInFolder1 = filesInFolder1(~[filesInFolder1.isdir]);
filesInFolder2 = filesInFolder2(~[filesInFolder2.isdir]);

% Extract the file names from the structures
S1 = {filesInFolder1.name};
S2 = {filesInFolder2.name};

clear filesInFolder1 filesInFolder2 folder1 folder2
%% states.PresentationPhase == The label for up down and resting 
%% 
load(S1{100});
fs = 500;

% Call the function for adjusting configuration
[signal, channels] = selectEEGChannels(signal, 'Parietal');
signal = resample(signal,1,5); % Resample


%% Band pass filter to see the power of a band change over time (55-85 for LS and GH 2-5Hz)
bpsignal = bandpass(signal,[55 85],fs);

for i = 1:length(signal)-fs*3
    bp(i,:) = bandpower(bpsignal(i:i+fs*3,:), fs, [55 85]);
    display(i);
end

bp = normalize(bp);
%%
figure()
for i = 1:size(bp,2)
    subplot(size(bp,2),1,i)
    plot(bp(:,i));
    hold on
    plot(resample(double(states.PresentationPhase),1,5));
end

%%
figure()
for i = 1:size(bp,2)
    subplot(size(bp,2),1,i)
    plot(bp(:,i));
    hold on
    plot(resample(double(states.PresentationPhase),1,5));
end