function [S,config] = trainPreProcess(config)

f = findSession(config);

% Initialize a struct to hold all the loaded and processed data
allData = struct('parameters', {}, 'signal', {}, 'states', {}, 'label', {}, 'channels', {});

% Iterate over each file in the cell array f
for i = 1:length(f)
    % Load the current file
    data = load(f{i});
    
    % Check if the loaded data contains the expected fields
    if isfield(data, 'parameters') && isfield(data, 'signal') && isfield(data, 'states')
        % Extract signal and states
        signal = data.signal;
        states = data.states;
        
        % Select EEG channels
        [signal, channels] = selectEEGChannels(signal, config.channel);
        
        % Resample the signal (computational redundancy)
        signal = resample(signal, config.resample1, config.resample2);
        
        % Bandpass filter the signal
        signal = bandpass(signal, config.bpf, config.fs);
        
        % Resample and process the label (computational redundancy)
        label = resample(double(states.PresentationPhase), config.resample1, config.resample2);
        label = round(label);
        %label = label + 1; % Makes Re = 1, Up = 2, Down = 3;
        
        % Store the processed data in allData
        allData(i).parameters = data.parameters;
        allData(i).signal = signal;
        allData(i).states = states;
        allData(i).label = label;
        allData(i).channels = channels;
    else
        % Issue a warning if the file does not contain the expected fields
        warning('File %s does not contain the expected fields.', f{i});
    end
end

%g = 1:2:length(allData);
%allData(g) = [];
% Display the resulting struct
%disp(allData);

S = [];
config.channels = allData.channels;
for i = 1:length(allData)
    X = split(config.workingfs, allData(i).label, allData(i).signal);
    S = horzcat(S,X);
end

%S = LRvRe(S);

end