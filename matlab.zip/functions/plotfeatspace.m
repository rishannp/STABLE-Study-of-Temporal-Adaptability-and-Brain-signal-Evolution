function plotfeatspace(feat, y)
    figure;

    % Define the unique labels
    uniqueLabels = unique(y);

    % Define colors for each class
    colors = lines(numel(uniqueLabels)); % Generate a colormap

    hold on; % Hold on to plot each class separately

    % Plot each class separately to ensure correct colors
    for i = 1:numel(uniqueLabels)
        classIdx = y == uniqueLabels(i);
        scatter3(feat(classIdx, 1), feat(classIdx, 2), feat(classIdx, 3), 36, colors(i,:), 'filled');
    end

    % Customize the legend
    legendEntries = arrayfun(@(x) ['Class ' num2str(x)], uniqueLabels, 'UniformOutput', false);
    legend(legendEntries, 'Location', 'best');

    % Set the axis labels for clarity
    xlabel('Feature 1');
    ylabel('Feature 2');
    zlabel('Feature 3');

    % Add a title
    title('3D Scatter Plot of Features with Class Labels');

    hold off; % Release the hold
end
