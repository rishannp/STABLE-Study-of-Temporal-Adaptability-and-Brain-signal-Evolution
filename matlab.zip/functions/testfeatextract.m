function [feat_test,test_label] = testfeatextract(W,SF,testdata,testlabel)

test_label = round(mean(testlabel));

X = testdata';
X_whitened = W * X; 
Za = SF.a * X_whitened; % Za is m x T
Zb = SF.b * X_whitened; % Zb is m x T
Zc = SF.c * X_whitened; % Zc is m x T

var_a = var(Za, 1, 2); % Variance of each row of Za, var_a is m x 1
var_b = var(Zb, 1, 2); % Variance of each row of Zb, var_b is m x 1
var_c = var(Zc, 1, 2); % Variance of each row of Zc, var_c is m x 1


feat_a = log10(var_a / sum(var_a)); % feat_a is m x 1
feat_b = log10(var_b / sum(var_b)); % feat_b is m x 1
feat_c = log10(var_c / sum(var_c)); % feat_c is m x 1
feat_test = [feat_a, feat_b, feat_c]; % feat_test is 3m x 1
% feat_test.a = feat_a;
% feat_test.b = feat_b;
% feat_test.c = feat_c;
end