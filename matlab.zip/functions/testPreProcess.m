function [signal,label] = testPreProcess(config,i)

fileName = config.patient{i};
load(fileName);

% Select EEG channels
[signal, channels] = selectEEGChannels(signal, config.channel);
% Resample the signal (computational redundancy)
signal = resample(signal, config.resample1, config.resample2);
% Bandpass filter the signal
signal = bandpass(signal, config.bpf, config.fs);
% Resample and process the label (computational redundancy)
label = resample(double(states.PresentationPhase), config.resample1, config.resample2);
label = round(label);


end

