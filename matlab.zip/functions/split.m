function S = split(fs, target, eeg)

% This function is for splitting data when in training/retraining phase.
% This function allows for the splitting of different classes into their
% own variables held in a struct. It makes it easy to train on. 

x = target;
x == 2
L = ans;
L(end) = 0;
clear ans

x == 3
R = ans;
R(end) = 0;
clear ans

x == 1
Re = ans;
Re(1) = 0;
Re(end) = 0;
clear ans

% The code above creates a separate variable for each class where they host
% their label in time.

flagL = zeros(1,length(x));
flagR = zeros(1,length(x));
flagRe = zeros(1,length(x));


for i = 2:length(L)
    % find first 1
    if L(i) == 1 && L(i-1) == 0 && L(i+1) == 1
        flagL(i) = 1;
    end
    if L(i) == 1 && L(i-1) == 1 && L(i+1) == 0
        flagL(i) = 1;
    end

    if R(i) == 1 && R(i-1) == 0 && R(i+1) == 1
        flagR(i) = 1;
    end
    if R(i) == 1 && R(i-1) == 1 && R(i+1) == 0
        flagR(i) = 1;
    end

    if Re(i) == 1 && Re(i-1) == 0 && Re(i+1) == 1
        flagRe(i) = 1;
    end
    if Re(i) == 1 && Re(i-1) == 1 && Re(i+1) == 0
        flagRe(i) = 1;
    end
end

[~,locL] = findpeaks(flagL);
[~,locR] = findpeaks(flagR);
[~,locRe] = findpeaks(flagRe); % Finding the location of the start and stop of each presentation of the class

clear flagL flagR flagRe L R Re x

a = [length(locL),length(locR),length(locRe)];
b = min(a); % Truncating the larger amount of Resting class compared to L/R

% NOTE: This can be changed to include adding MUCH more data.

for j = 1:2:(b)-1
    eegL = eeg([locL(j):locL(j+1)],:);
    eegR = eeg([locR(j):locR(j+1)],:);
    eegRe = eeg([locRe(j):locRe(j+1)],:);
    S(j) = struct('L',eegL,'R',eegR,'Re',eegRe);
end

S([2:2:size(S,2)]) = [];
end