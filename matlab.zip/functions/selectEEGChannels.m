function [selectedData, selectedChannels] = selectEEGChannels(data, configType)
    % Load the .mat file
    loadedData = load("EEGLabLocsMPICap.mat");
    locsStruct = loadedData.Chanlocs;

    % Extract the labels and coordinates from the struct
    allLabels = {locsStruct.labels};
    allCoords = arrayfun(@(s) [s.X, s.Y, s.Z], locsStruct, 'UniformOutput', false);
    allCoords = vertcat(allCoords{:});

    % Define channel names for 10-20, 10-10 systems, and all parietal electrodes
    channelNames_10_20 = {
        'Fp1', 'Fp2', 'F7', 'F3', 'Fz', 'F4', 'F8', ...
        'T7', 'C3', 'Cz', 'C4', 'T8', ...
        'P7', 'P3', 'Pz', 'P4', 'P8', ...
        'O1', 'O2'
    };

    channelNames_10_10 = {
        'Fp1', 'Fpz', 'Fp2', 'AF7', 'AF3', 'AFz', 'AF4', 'AF8', ...
        'F7', 'F5', 'F3', 'F1', 'Fz', 'F2', 'F4', 'F6', 'F8', ...
        'FT7', 'FC5', 'FC3', 'FC1', 'FCz', 'FC2', 'FC4', 'FC6', 'FT8', ...
        'T7', 'C5', 'C3', 'C1', 'Cz', 'C2', 'C4', 'C6', 'T8', ...
        'TP7', 'CP5', 'CP3', 'CP1', 'CPz', 'CP2', 'CP4', 'CP6', 'TP8', ...
        'P7', 'P5', 'P3', 'P1', 'Pz', 'P2', 'P4', 'P6', 'P8', ...
        'PO7', 'PO3', 'POz', 'PO4', 'PO8', ...
        'O1', 'Oz', 'O2', 'Iz'
    };

    parietalChannels = {
        'P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7', 'P8', 'P9', 'P10', ...
        'Pz', 'P1P', 'P2P', 'P3P', 'P4P', 'P5P', 'P6P', 'P7P', 'P8P', 'P9P', ...
        'P10P', 'PzP', 'P1A', 'P2A', 'P3A', 'P4A', 'P5A', 'P6A', 'P7A', 'P8A', ...
        'PO1', 'PO2', 'PO3', 'PO4', 'POz',  'TP7', 'CP5', 'CP3', 'CP1', 'CPz', ...
        'CP2', 'CP4', 'CP6', 'TP8', 'O1', 'Oz', 'O2';
    };

    % Determine the channel names to use based on the configuration type
    switch configType
        case '10-20'
            selectedChannels = channelNames_10_20;
        case '10-10'
            selectedChannels = channelNames_10_10;
        case 'Parietal'
            selectedChannels = parietalChannels;
        otherwise
            error('Invalid configuration type. Choose either "10-20", "10-10", or "Parietal".');
    end

    % Initialize arrays to store the matched selected channels, their indices, and coordinates
    matchedChannels = {};
    selectedIndices = [];
    matchedCoords = [];

    % Loop through the selected channels and find their indices in the allLabels
    for i = 1:length(selectedChannels)
        idx = find(strcmp(selectedChannels{i}, allLabels));
        if ~isempty(idx)
            selectedIndices(end + 1) = idx; %#ok<AGROW>
            matchedChannels{end + 1} = selectedChannels{i}; %#ok<AGROW>
            matchedCoords = [matchedCoords; allCoords(idx, :)]; %#ok<AGROW>
        end
    end

    % Select the columns of the data corresponding to the matched selected channels
    selectedData = data(:, selectedIndices);
    selectedChannels = table(matchedChannels', matchedCoords(:,1), matchedCoords(:,2), matchedCoords(:,3), ...
                             'VariableNames', {'Channel', 'X', 'Y', 'Z'});
end
