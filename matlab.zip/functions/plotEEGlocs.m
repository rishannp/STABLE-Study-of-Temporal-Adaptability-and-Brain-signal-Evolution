function plotEEGlocs(config)
    labels = config.channels.Channel;
    X = config.channels.X;
    Y = config.channels.Y;
    Z = config.channels.Z;
    
    % Plotting the 3D scatter plot
    figure;
    scatter3(X, Y, Z, 'filled');
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    title('EEG Channel Locations');
    grid on;
    
    % Add labels for each point (optional)
    text(X, Y, Z, labels, 'VerticalAlignment','bottom', 'HorizontalAlignment','right');
    
    % Adjust the view for better visibility
    view(3);

end

