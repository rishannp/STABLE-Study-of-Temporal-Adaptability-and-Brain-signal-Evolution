function [c] = delOdds(config)
a = config.patient; % Cell array containing filenames of patient data

% Extract session numbers from the filenames in config.patient
b = cellfun(@(x) x(8:9), config.patient, 'UniformOutput', false); % Extract the session number (characters 5 and 6)
b = cellfun(@(x) str2double(x), b); % Convert the extracted session numbers to double

even_mask = mod(b, 2) == 0;
% Extract the even numbers
even_numbers = b(even_mask);

% Get the indices of the even numbers
even_indices = find(even_mask);

c = a(even_indices);
end