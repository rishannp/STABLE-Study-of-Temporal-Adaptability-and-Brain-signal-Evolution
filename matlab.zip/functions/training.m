function [mdl,accuracy, SF, W, feat, label] = training(train,m)

[W, SF.a,SF.b,SF.c,feat, label] = mcsp(train,m);

[mdl.L, accuracy.L] = enblKNN(feat.L, label.yl);
[mdl.R, accuracy.R] = enblKNN(feat.R, label.yr);
[mdl.Re, accuracy.Re] = enblKNN(feat.R, label.yre);
end

