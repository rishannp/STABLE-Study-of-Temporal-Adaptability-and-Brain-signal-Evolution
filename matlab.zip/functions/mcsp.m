function [W, SFa,SFb,SFc,feat, label] = mcsp(train,m) % https://doi.org/10.1109/IEMBS.2005.1616947 ...
% by Wu, Gao and Gao, EMBC (2005)

% Loop through each trial to compute the covariance matrices for each class
for i = 1:size(train,2)
    class1 = train(i).L'; % Class 1 EEG data (NxT)
    class2 = train(i).R';
    class3 = train(i).Re';
    
    R1(:,:,i) = covar(class1); % Equation (1): Covariance matrix for Class 1
    R2(:,:,i) = covar(class2);
    R3(:,:,i) = covar(class3);  
end

% Average the covariance matrices across trials
R1 = mean(R1,3); % Covariance matrix for Class 1
R2 = mean(R2,3); % Covariance matrix for Class 2
R3 = mean(R3,3); % Covariance matrix for Class 3

% Equation (2): Composite Covariance Matrix
R = R1 + R2 + R3;

% Equation (3): Eigenvalue decomposition of the composite covariance matrix
[V, D] = eig(R); % V = U, D = Lambda

% Equation (4): Whitening Matrix
W = sqrtm(inv(D)) * V';

%% Left Class (Class 1)
% Ra is the covariance matrix for Class 1
Ra = R1;

% Ra' is the sum of the covariance matrices for the other classes
Rbc = R2 + R3; % Equation Ra' = Rb + Rc

% Equation (5) and (6): Transform covariance matrices
Sa = W * Ra * W';
Sbc = W * Rbc * W';

% Decompose Sa and Sbc
[SaV, SaD] = decompose_S(Sa, 'descending'); % Eigen decomposition, sorted descending
[SbcVt, SbcDt] = decompose_S(Sbc, 'ascending'); % Eigen decomposition, sorted ascending

% Check the eigenvalue condition
check = SaD + SbcDt; 
check = mean(check);

% Select top m eigenvectors
SaV(:,[m+1:end-m]) = [];

% Equation (12): Spatial Filter for Class 1
SFa = SaV' * W;

% Apply the spatial filter to the EEG data for each trial
for i = 1:size(train,2)
    Za = SFa * train(i).L'; % Resulting matrix size will be 2xT

    % Compute log-variance of the projected signals
    var1 = var(Za, 1, 2);
    varsum = sum(var1);
    featL(i,:) = log10(var1 / varsum);
    clear var1 varsum
end

%% Right Class (Class 2)
Ra = R2; % Class 2

Rbc = R1 + R3; % Class 1 and 3 (Equation Ra' = Rb + Rc)

Sa = W * Ra * W'; 
Sbc = W * Rbc * W';

[SaV, SaD] = decompose_S(Sa, 'descending');
[SbcVt, SbcDt] = decompose_S(Sbc, 'ascending');

check = SaD + SbcDt; 
check = mean(check);

SaV(:,[m+1:end]) = [];

SFb = SaV' * W; % Equation (12) : Spatial Filter for Class B

for i = 1:size(train,2)
    Zb = SFb * train(i).R'; % Resulting matrix size will be 2xT

    var1 = var(Zb, 1, 2);
    varsum = sum(var1);
    featR(i,:) = log10(var1 / varsum);
    clear var1 varsum
end

%% Rest Class (Class 3)
Ra = R3; % Class 3

Rbc = R1 + R2; % Class 1 and 2 (Equation Ra' = Rb + Rc)

Sa = W * Ra * W'; 
Sbc = W * Rbc * W';

[SaV, SaD] = decompose_S(Sa, 'descending');
[SbcVt, SbcDt] = decompose_S(Sbc, 'ascending');

check = SaD + SbcDt; 
check = mean(check);

SaV(:,[m+1:end]) = [];

SFc = SaV' * W; % Equation (12) : Spatial Filter for Class C

for i = 1:size(train,2)
    Zc = SFc * train(i).Re'; % Resulting matrix size will be 2xT

    var1 = var(Zc, 1, 2);
    varsum = sum(var1);
    featRe(i,:) = log10(var1 / varsum);
    clear var1 varsum
end

%% Combine features and create labels
feat = [featRe; featL; featR];
label = [ones(size(train,2),1); ones(size(train,2),1)*2; ones(size(train,2),1)*3]; % Re = 3, L = 1, R = 2
% feat.L = [featL; featRe;  featR];
% label.yl = [ones(size(train,2),1); zeros(size(train,2)*2,1)];
% 
% feat.R = [featR; featL;  featRe];
% label.yr = [ones(size(train,2),1); zeros(size(train,2)*2,1)];
% 
% feat.Re = [featRe; featL;  featR];
% label.yre = [ones(size(train,2),1); zeros(size(train,2)*2,1)];

end