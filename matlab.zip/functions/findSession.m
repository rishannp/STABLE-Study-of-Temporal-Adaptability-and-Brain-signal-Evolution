function f = findSession(config)
x = config.trainingduration; % Number of sessions to consider (e.g., 2 sessions)
a = config.patient; % Cell array containing filenames of patient data

% Extract session numbers from the filenames in config.patient
b = cellfun(@(x) x(5:6), config.patient, 'UniformOutput', false); % Extract the session number (characters 5 and 6)
b = cellfun(@(x) str2double(x), b); % Convert the extracted session numbers to double

% Find the minimum session number
c = min(b);

% Initialize an empty array to store indices of selected sessions
idx = [];
missing_count = 0; % Counter for consecutive missing sessions
max_missing = 2; % Maximum allowed consecutive missing sessions

% Loop to find indices of the first 'x' sessions in sequence
for i = 1:x
    % Calculate the session number to search for
    value_to_search = c + (i - 1);
    
    % Check if value_to_search exists in b
    if ismember(value_to_search, b)
        % Find indices where b equals value_to_search
        d = find(b == value_to_search);
        
        % Append the found indices to idx
        idx = [idx, d]; % Append d to idx
        
        % Reset the missing count as we found a session
        missing_count = 0;
    else
        % Handle case where value_to_search is not found in b
        fprintf('Session %d not found in array b\n', value_to_search);
        
        % Increase the missing count
        missing_count = missing_count + 1;
        
        % Check if consecutive missing sessions exceed the limit
        if missing_count >= max_missing
            fprintf('Reached maximum consecutive missing sessions. Stopping search.\n');
            break; % Exit the loop
        end
        
        % Adjust i to try the next session in the next iteration
        i = i + 1;
    end
end

% Select filenames based on the found indices
f = a(idx);

end

